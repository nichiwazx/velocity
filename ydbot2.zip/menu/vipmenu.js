const vipmenu = (prefix) => { 
	return `          「 *VIP MENU👑* 」 

› ${prefix}ytmp4
› ${prefix}ytmp3
› ${prefix}ytsearch
› ${prefix}spotify [LINK DI SPOTIFY SEARCH]
› ${prefix}spotifysearch
› ${prefix}wancak
› ${prefix}spamcall
› ${prefix}spamsms

*Terima kasih yang sudah premium😁*`
}
exports.vipmenu = vipmenu