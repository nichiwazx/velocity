const simplemenu = (prefix) => { 
	return `          「 *SIMPLE MENU* 」 

› ${prefix}stiker
› ${prefix}ttp
› ${prefix}attp
› ${prefix}tts
› ${prefix}nulis
› ${prefix}nulis2 nama/kelas/teks
› ${prefix}soundmenu`
}
exports.simplemenu = simplemenu