const soundmenu = (prefix) => { 
	return `          「 *SOUND MENU* 」 

*Sound islam☪️*
› ${prefix}ayatkursi2
› ${prefix}tilawah
› ${prefix}sholawatnabi
› ${prefix}ngaji
› ${prefix}ngaji2

*Sound Jedag jedug🔊*
› ${prefix}iri
› ${prefix}pale
› ${prefix}sound
› ${prefix}sound1
› ${prefix}sound2
› ${prefix}sound3
› ${prefix}sound4
› ${prefix}sound5
› ${prefix}sound6
› ${prefix}sound7

*Sound Musik🎧* 
› ${prefix}sad
› ${prefix}sad2
› ${prefix}sad3
› ${prefix}sad4
› ${prefix}aeshtetic
› ${prefix}aeshtetic2
› ${prefix}aeshtetic3
› ${prefix}aeshtetic4
› ${prefix}home
› ${prefix}gettingold
› ${prefix}allnight
› ${prefix}lucas
› ${prefix}wanna
› ${prefix}yourskin
› ${prefix}up
› ${prefix}cutmeoff
› ${prefix}beautiful
› ${prefix}loosinggame
› ${prefix}loosinginterest
› ${prefix}playdate`
}
exports.soundmenu = soundmenu