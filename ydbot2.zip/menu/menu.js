const menu = (prefix, pushname, uangku, role, getLevelingLevel(sender), getLevelingXp(sender)}/reqXp, sender.split("@")[0]) => { 
	return `◪ INFO DEVELOPER
  ❏ Nama: YogiPw
  ❏ Wa: wa.me/6283152753417
  ❏ Ig: https://instagram.com/yogi.prwaa._
  ----------------------------------
◪ YOUR INFO
  ❏ Prefix: 「  ${prefix}  」
  ❏ Nama: ${pushname}
  ❏ Duit: *Rp.${uangku}.-*
  ❏ Role: *${role}*
  ❏ Level: ${getLevelingLevel(sender)}
  ❏ Xp: ${getLevelingXp(sender)}/${reqXp} 
  ❏ Nomer: wa.me/${sender.split("@")[0]}
  ----------------------------------

*${prefix}info*
*${prefix}snk*
*${prefix}lpr*
*${prefix}request*
*${prefix}blocklist*
*${prefix}ping*
*${prefix}buypremium*
*${prefix}hargaprem*

  *⧉ GROUP MENU*
› ${prefix}welcome [1/0]
› ${prefix}nsfw [1/0]
› ${prefix}antilink [1/0]
› ${prefix}leveling [1/0]
› ${prefix}nobadword [1/0]
› ${prefix}simih [1/0] 
› ${prefix}promote [@tag]
› ${prefix}demote [@tag]
› ${prefix}tagall
› ${prefix}listadmin
› ${prefix}wakillist
› ${prefix}premiumlist
› ${prefix}banlist
› ${prefix}blocklist
› ${prefix}linkgc
› ${prefix}mining
› ${prefix}hidetag
› ${prefix}grouplist
› ${prefix}add [62]
› ${prefix}kick [@tag]
› ${prefix}setname
› ${prefix}setdesc
› ${prefix}setpp
› ${prefix}listadmin
› ${prefix}linkgc
› ${prefix}leave
› ${prefix}mining
› ${prefix}level
› ${prefix}grup [buka/tutup)

  *⧉ OWNER MENU*
› ${prefix}bc
› ${prefix}addbadword
› ${prefix}delbadword
› ${prefix}bcgc
› ${prefix}kickall
› ${prefix}setreply
› ${prefix}setprefix
› ${prefix}clearall
› ${prefix}block
› ${prefix}unblock
› ${prefix}leave
› ${prefix}event [1/0]
› ${prefix}clone
› ${prefix}setppbot

  *⧉ INFORMATION MENU*
› ${prefix}covidindo
› ${prefix}infonomor
› ${prefix}infogempa
› ${prefix}infocuaca
› ${prefix}infofilm
› ${prefix}jadwaltv
› ${prefix}jadwalsholat
› ${prefix}tribunews
› ${prefix}liputan6
› ${prefix}foxnews
› ${prefix}apkpure
› ${prefix}film1
› ${prefix}film2
› ${prefix}lirik
› ${prefix}searchfilm
› ${prefix}nickff
› ${prefix}resepmasakan

  *⧉ MAKER MENU*
› ${prefix}sticker
› ${prefix}ttp
› ${prefix}attp
› ${prefix}nulis
› ${prefix}nulis2
› ${prefix}shadow
› ${prefix}cup
› ${prefix}cup1
› ${prefix}romance
› ${prefix}smoke
› ${prefix}burnpaper
› ${prefix}lovemessage
› ${prefix}undergrass
› ${prefix}love
› ${prefix}coffe
› ${prefix}woodheart
› ${prefix}flowerheart
› ${prefix}woodenboard
› ${prefix}summer3d
› ${prefix}wolfmetal
› ${prefix}nature3d
› ${prefix}underwater
› ${prefix}golderrose
› ${prefix}summernature
› ${prefix}letterleaves
› ${prefix}glowingneon
› ${prefix}fallleaves
› ${prefix}flamming
› ${prefix}harrypotter
› ${prefix}carvedwood
› ${prefix}wetglass
› ${prefix}multicolor3d
› ${prefix}watercolor
› ${prefix}luxurygold
› ${prefix}galaxywallpaper
› ${prefix}lighttext
› ${prefix}beautifulflower
› ${prefix}puppycute
› ${prefix}royaltext
› ${prefix}heartshaped
› ${prefix}birthdaycake
› ${prefix}galaxystyle
› ${prefix}hologram3d
› ${prefix}glossychrome
› ${prefix}greenbush
› ${prefix}metallogo
› ${prefix}noeltext
› ${prefix}glittergold
› ${prefix}textcake
› ${prefix}starsnight
› ${prefix}wooden3d
› ${prefix}textbyname
› ${prefix}writegalacy
› ${prefix}galaxybat
› ${prefix}snow3d
› ${prefix}birthdayday
› ${prefix}goldplaybutton
› ${prefix}silverplaybutton
› ${prefix}freefire
› ${prefix}tahta
› ${prefix}darkneon
› ${prefix}candlemug
› ${prefix}lovemsg
› ${prefix}mugflower
› ${prefix}narutobanner
› ${prefix}paperonglass
› ${prefix}romancetext
› ${prefix}shadowtext
› ${prefix}coffeecup
› ${prefix}coffeecup2
› ${prefix}glowingneon
› ${prefix}underwater
› ${prefix}hpotter
› ${prefix}woodblock
› ${prefix}gplaybutton
› ${prefix}splaybutton
› ${prefix}barcode
› ${prefix}qrencode
› ${prefix}ttp
› ${prefix}attp
› ${prefix}jokerlogo
› ${prefix}calendermaker
› ${prefix}pornhub
› ${prefix}googletext
› ${prefix}glitchtext
› ${prefix}crosslogo
› ${prefix}naruto
› ${prefix}flowertext
› ${prefix}silktext
› ${prefix}flametext
› ${prefix}glowtext
› ${prefix}skytext
› ${prefix}cslogo
› ${prefix}lithgtext
› ${prefix}crismes
› ${prefix}bneon
› ${prefix}matrix
› ${prefix}breakwall
› ${prefix}dropwater
› ${prefix}leavest
› ${prefix}logobp
› ${prefix}fftourserti
› ${prefix}fftourserti2
› ${prefix}fftourserti3
› ${prefix}fftourserti4
› ${prefix}fftourserti5
› ${prefix}pubgtourserti
› ${prefix}pubgtourserti2
› ${prefix}pubgtourserti3
› ${prefix}pubgtourserti4
› ${prefix}pubgtourserti5
› ${prefix}mltourserti
› ${prefix}mltourserti2
› ${prefix}mltourserti3
› ${prefix}mltourserti4
› ${prefix}mltourserti5
› ${prefix}tweetfake
› ${prefix}babu
› ${prefix}bucinserti
› ${prefix}bocilepep
› ${prefix}gayserti
› ${prefix}pacar
› ${prefix}sadboy
› ${prefix}surga
› ${prefix}pintar
› ${prefix}badboy
› ${prefix}badgirl
› ${prefix}goodboy
› ${prefix}goodgirl
› ${prefix}editorberkelas
› ${prefix}phcomment nama/comen
› ${prefix}wallgravity teks1/teks2
› ${prefix}marvelstudio teks1/teks2
› ${prefix}space teks1/teks2
› ${prefix}glitch teks1/teks2
› ${prefix}pubglogo teks1/teks2

  *⧉ IMAGE EDIT MENU*
› ${prefix}wanted
› ${prefix}gtav
› ${prefix}crossgun
› ${prefix}bakar
› ${prefix}facebookpage
› ${prefix}costumwp
› ${prefix}pantaimalam
› ${prefix}pencil
 
  *⧉ FUN MENU*
› ${prefix}jadian
› ${prefix}ngewe
› ${prefix}terganteng
› ${prefix}tercantik
› ${prefix}gantengcek
› ${prefix}cantikcek
› ${prefix}sangecek
› ${prefix}gaycek
› ${prefix}lesbicek
› ${prefix}watak
› ${prefix}hobby
› ${prefix}apakah
› ${prefix}kapankah
› ${prefix}bisakah
› ${prefix}bagaimanakah
› ${prefix}rate
› ${prefix}alay
› ${prefix}fml
› ${prefix}katacinta
› ${prefix}pantun
› ${prefix}hilih
› ${prefix}holoh
› ${prefix}halah
› ${prefix}hurufterbalik
 
   *⧉ APK MENU*
› ${prefix}apkpure
› ${prefix}happymod
› ${prefix}moddroid
 
  *⧉ MEDIA MENU*
› ${prefix}brainly 
› ${prefix}pinterest
› ${prefix}resepmasakan
› ${prefix}igstalk
› ${prefix}bitly
› ${prefix}tiktokstalk 
› ${prefix}ssweb
› ${prefix}kbbi
› ${prefix}meme
› ${prefix}memeindo
› ${prefix}github
› ${prefix}wancak
› ${prefix}semoji 
› ${prefix}fakeaddress

  *⧉ DOWNLOAD*
› ${prefix}joox 
› ${prefix}jooxplay
› ${prefix}ytsearch
› ${prefix}ytmp4 
› ${prefix}ytmp3 
› ${prefix}play
› ${prefix}spotify 
› ${prefix}spotifysearch 
 
  *⧉ ANIME MENU*
› ${prefix}peluk
› ${prefix}cium
› ${prefix}husbu
› ${prefix}ranime
› ${prefix}waifu
› ${prefix}animeboy
› ${prefix}animegirl
› ${prefix}animeimg
› ${prefix}loli
› ${prefix}shota
› ${prefix}neko
› ${prefix}animehug
› ${prefix}animecry

 *⧉ NSFW MENU*
› ${prefix}randomhentai 
› ${prefix}randomsfw
› ${prefix}randomnsfw
› ${prefix}sfw
› ${prefix}nsfw
› ${prefix}nsfwneko 

  *⧉ RANDOM IMAGE*
› ${prefix}aesthetic
› ${prefix}fotocewek 
› ${prefix}doraemon 
› ${prefix}pokemon 
› ${prefix}kucing 
› ${prefix}hamster 
› ${prefix}kelinci 
› ${prefix}freefireimg 
› ${prefix}ww2 
› ${prefix}shota 
› ${prefix}neko 
› ${prefix}randomexo
› ${prefix}randombts
› ${prefix}imagegame
› ${prefix}imagemountain
› ${prefix}randomkpop
› ${prefix}doraemon 
› ${prefix}pokemon  
 
  *⧉ QUOTES MENU*
› ${prefix}quotesislami
› ${prefix}quotesnasehat
› ${prefix}quotesmotivasi
› ${prefix}quoteskehidupan
› ${prefix}katailham
› ${prefix}katabijak
› ${prefix}bacotanhacker
› ${prefix}quotedoraemon

 *⧉ LIMIT & UANG*
› ${prefix}limit
› ${prefix}buylimit
› ${prefix}buypremiumlimit
› ${prefix}transfer
› ${prefix}leaderboard
 
 *⧉ TOOLS*
› ${prefix}bass
› ${prefix}toimg
› ${prefix}tomp3
› ${prefix}slowmo
› ${prefix}gemok
› ${prefix}tupai
› ${prefix}tinyurl
› ${prefix}bitly
› ${prefix}ocr
› ${prefix}tts
› ${prefix}kalkulator
 
 *⧉ STORAGE*
› ${prefix}addsticker
› ${prefix}getsticker
› ${prefix}stickerlist
› ${prefix}addvideo
› ${prefix}getvideo
› ${prefix}videolist
› ${prefix}getimage
› ${prefix}addImage
› ${prefix}imagelist
› ${prefix}addaudio
› ${prefix}getaudio
› ${prefix}audiolist

 *⧉ OTHER MENU*
› ${prefix}soundmenu
› ${prefix}simplemenu
› ${prefix}vipmenu [PREMIUM]

⚠️ *ABOUT BOT*
› Name : ${client.user.name}
› Browser : ${client.browserDescription[1]}
› Server : ${client.browserDescription[0]}
› Version : ${client.browserDescription[2]}
› Speed : ${process.uptime()}
› Handphone : ${client.user.phone.device_manufacturer}
› Versi Whatsapp : ${client.user.phone.wa_version}
 
[ TQTO ]
•YOGIPW
•Msz Pros *(Hans)*
•Alpinofc *(GayMan)*
•Dappauhuy *(GayBerkualitas)*
•Arul 818 *(Yaoi)*
 
📄NOTE : 
1. *[ MAINTENANCE ]* Jika ada tanda maintenance.. berarti fitur tersebut sedang error dan sedang diperbaiki😊

2. Spam call,Spam command = *BLOCK + BANNED*`
}
exports.menu = menu